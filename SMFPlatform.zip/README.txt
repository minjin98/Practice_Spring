 <%
   Vector<ProcessBean> vlist = regMgr.getRegisterList();
	int counter = vlist.size();
	for(int i = 0; i < vlist.size(); i++) {
   		ProcessBean proBean = vlist.get(i);
%>

RegisterMgr


<ProcessDao>
// DB에서 여러개의 행을 받아와서 rs.getString을 이용해 칼럼별로 분리
// 무조건 칼럼 기준이 아니라 행을 기준으로 계산한다.
public List<ProcessBean> select_rate() {
		List<ProcessBean> results = jdbcTemplate.query("select * from prod_rate",
				new RowMapper<ProcessBean>() {
					@Override
					public ProcessBean mapRow(ResultSet rs, int rowNum) throws SQLException {
						ProcessBean process = new ProcessBean(
								rs.getString("goodprod_rate"),
								rs.getString("badprod_rate"));
						return process;				
					}
			});
	return results;
	}




@GetMapping("/process3") // 주소창에 process3 입력시 실행
    public String manage(Model model) { // 파라미터에 Model model 선언
    	// ProcessDao에서 선언한 selectAll을 통해  데이터를 불러와 List<ProcessBean>에 저장
		List<ProcessBean> processList = processDao.selectAll();
		// processList에 저장된 값들을 "processList" 이름으로 JSP에 전달 
		model.addAttribute("processList", processList);
    	return "test3.jsp";
   }


// ProcessController에서 processList로 넘겨준 데이터를 별도의 선언 없이
// 바로 사용
<c:forEach var="proc" items="${processList}" >
    <span>${proc.prodName}</span>
</c:forEach>	



콤보박스 항목에 호출 값을 지정해서 콤보박스 항목 선택시 해당된 값들이 호출(작업해야함)
Bar chart 의 cycletime 데이터 랜덤 출력
Controller 집중적으로 보기

String 으로 받은 객체는 for:each 로 반복할 수 없다.

// c:if = "${not empty vals}"  vals 값이 비어있지 않을때만 실행 
<c:if test="${not empty process_gauge}">
     		var process_gauge_val = parseFloat(${process_gauge.process_gauge});
     		gaugeChart(process_gauge_val);
 		</c:if>


<Controller 사용법>
1. Controller 생성
2. ControllerConfig에 생성한 Controller 등록

<%--forEach 로 꺼낸 데이터들 중에서 항목에 해당하는 값 전송>
	a hef="" 로 Controller의 Mapping을 호출
	호출할 때 파라미터의 값을 같이 전송
	Controller에서는 @RequestParm으로 넘어온 데이터 받기--%>
	ex)
		<a href="/SMFPlatform/testORDelete?prodNo=${order.prodNo}">취소</a>
		
Dao에 구현시 insert, delete, update 전부 jdbcTemplate.update 로 사용 (예제:S08JdbcTemplate 참고)
query문은 select 시에만 사용

$(document).ready(function() {
		        $(".lineSelect").click(function() { // "lineSelect"가 클릭되었을때 함수 실행(클래스 설정) => 여러 개의 값들을 동일한 클래스명으로 설정 가능
		        	var lineid = $(this).prop("id"); // "lineSelect"에서 실행된 함수 "id"의 property 값을 "lineid"에 저장 (ordernum${})
		            var sel = $("#line"+lineid).val();
		        	alert(sel);
		  			var lineSelect = $(this).attr("href"); // ID가 "lineSelect"인 태그의 "href" 속성을 변수에 저장
		  			lineSelect += sel; // 저장된 "href"의 속성에 lineid 값을 붙이기
		  			$(this).attr("href", lineSelect); // ID가 "lineSelect"인 태그의 "href" 속성을 lineSelect 변수값으로 교체
		  			//alert($("#lineSelect").attr("href"));
		        });	
			});

<통합>
1. web.xml 주석부분으로 수정
2. MvcConfig 주석 해제
3. OracleDbConfig, OracleInfo 수정
4. 나머지 Process 코드들 수정
											