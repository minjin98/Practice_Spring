package exeptions;

public class WrongIdPasswordException extends RuntimeException {

}
