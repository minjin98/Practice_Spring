package controller.process;

public class OracleInfo {
	public static String _driver = "oracle.jdbc.driver.OracleDriver";
	public static String _url = "jdbc:oracle:thin:@localhost:1521:xe";
    public static String _user = "HELLOUSER";	
    public static String _password = "HELLOUSER";
}
