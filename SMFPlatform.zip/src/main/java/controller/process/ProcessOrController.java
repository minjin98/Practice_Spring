package controller.process;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;
import controller.process.ProcessBean;
import controller.process.ProcessDao;

@Controller
public class ProcessOrController {
private ProcessDao processDao;
	
	public ProcessOrController(ProcessDao processDao) {
		this.processDao = processDao;
	}
	
	@GetMapping("/testOR") // 주소창에 /process 입력시 실행
    public String single_value(Model model) {
		List<ProcessBean>orderlist = processDao.select_plan();
		model.addAttribute("orderlist", orderlist);
		System.out.println("orderlist 실행");
		return "test/testOR";
	}
	
	@GetMapping("/testORDelete")
	public String deleteProcess(Model model, @RequestParam("num") Integer num) {
		System.out.println("[ProcessOrController] deleteProcess: prodNo=" + num);
		processDao.deleteProcess(num);
		System.out.println("deleprocess 완료 2");
		
		List<ProcessBean>orderlist = processDao.select_plan();
		model.addAttribute("orderlist", orderlist);
		return "test/testOR";
	}
	
	@GetMapping("/testORstart")
	public String insertLine(Model model, @RequestParam("prodNo") String prodNo,@RequestParam("value") String value) {
		System.out.println("[ProcessOrController] insertLine : prodNo=" + prodNo);
		System.out.println("[ProcessOrController] insertLine : value=" + value);
		
		// DB 업데이트
		// 휘발성	
		String insertProdNo = prodNo;
		processDao.insertLineid(value, prodNo);
		model.addAttribute("insertProdNo", insertProdNo);
		return "test/test";
		/*
			if("1".equals(value)) {
			String oneline = processDao.selectOneLine(value);
			model.addAttribute("oneline", oneline);
		}
		
		else if("2".equals(value)) {
			String twoline = processDao.selectTwoLine(value);
			model.addAttribute("twoline", twoline);
		}
		
		else if("3".equals(value)){
			String threeline = processDao.selectThreeLine(value);
			model.addAttribute("threeline", threeline);
		}
		else {
			return "test/testOR";
		}
		*/
		/*
		String twoline = processDao.selectTwoLine();
		if(twoline == null) {
			System.out.println("2번공정 데이터 없음");
		}
		else {
			model.addAttribute("twoline", twoline);
		}
		
		String threeline = processDao.selectThreeLine();
		if(threeline == null) {
			System.out.println("3번공정 데이터 없음");
		}
		else {
			model.addAttribute("threeline", threeline);
		}*/
		
			
	}
	
		
}
