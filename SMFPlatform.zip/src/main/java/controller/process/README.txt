1. Process 클래스 생성
2. DB 연동 클래스 (OracleInfo, OracleDbConfig) 생성
3. DB 사용을 위한 ProcessDao 클래스 생성
