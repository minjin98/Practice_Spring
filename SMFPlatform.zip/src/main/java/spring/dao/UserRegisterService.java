package spring.dao;

public class UserRegisterService {

	public UserRegisterService(UserDao userDao) {
		// TODO Auto-generated constructor stub
	}

}
